
chrome.runtime.onMessage.addListener(
        function(request, sender, sendResponse) {
            console.log(sender.tab ?
                    "from a content script:" + sender.tab.url :
                    "from the extension");
            if (request.greeting === "hello"){
                t();
                sendResponse({farewell: "goodbye"});
            }
        });

let isSet = false;

function t(){
    // https://stackoverflow.com/questions/9515704/access-variables-and-functions-defined-in-page-context-using-a-content-script
    var actualCode = '_menu.open();';

    if (!isSet){
        document.documentElement.setAttribute('onreset', actualCode);
        isSet = true;
    }
    document.documentElement.dispatchEvent(new CustomEvent('reset'));

        document.documentElement.setAttribute('onreset', 'null');
    document.documentElement.removeAttribute('onreset');
}
